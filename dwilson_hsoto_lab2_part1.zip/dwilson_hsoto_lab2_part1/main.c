/*David Wilson (862134618)
 * Partner: Hector Soto Jr
 *Lab Section: 023
 * Assignment: Lab 2 Exercise 1
 *
 *I acknowledge all content contained herein, excluding template or example code, 
 *is my own original work
 */ 

#include <avr/io.h>


int main(void)
{
    DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
    DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs, initialize to 0s
    
	//section above is pulled from example provided in the lab
	
	unsigned char light=(0x00);//light censor initialization
	unsigned char garage=(0x00);//garage door initialization
	
	    while (1) {
			
			light=PINA & 0x02;
			light=light>>1;
			garage=PINA &0x01;
			
			PORTB=(!light&&garage);
    }
	return 1;
	
	
}

