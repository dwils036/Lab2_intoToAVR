/*David Wilson dwils036@ucr.edu
 * Partner: Hector Soto Jr
 *Lab Section: 023
 * Assignment: Lab 2 Exercise 2
 *Car port calculations
 *
 *I acknowledge all content contained herein, excluding template or example code, 
 *is my own original work
 */ 
#include <avr/io.h>

int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs, initialize to 0s

	unsigned char s1=0x00; //Occupied space 1
	unsigned char s2=0x00; //Occupied space 2
	unsigned char s3=0x00; //Occupied space 3
	unsigned char s4=0x00; //Occupied space 4

	unsigned char totalAval=0x00; //end amount available

	while (1)
	{
		
		s1=PINA & 0x01;
		s2=PINA & 0x02;
		s3=PINA & 0x04;
		s4=PINA & 0x08;

		if(s1){
		s1=0x01;
		}
		else{
		s1=0x00;
		}
		
		if(s2){
		s2=0x01;
		}
		else{
		s2=0x00;
		}
		
		if(s3){
		s3=0x01;
		}
		else{
		s3=0x00;
		}
		
		if(s4){
		s4=0x01;
		}
		else{
		s4=0x00;
		}
		
		totalAval=s1 + s2 + s3 + s4; //Adding occupied spaces
		totalAval=0x04 - totalAval; //4 - occupied space count gives spaces available
		PORTC=totalAval; //Spots available is written in binary
	}
}

